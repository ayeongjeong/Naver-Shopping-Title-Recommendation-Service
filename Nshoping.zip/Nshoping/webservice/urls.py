from webservice import views
from django.urls import path

urlpatterns = [
    path("main/", views.main),
    path('sub/', views.sub, name='sub'),
]


    
