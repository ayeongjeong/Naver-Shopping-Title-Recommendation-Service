import numpy as np
import pandas as pd
from bokeh.plotting import figure, output_file, show
from bokeh.io import output_notebook

# data
import requests
import json
client_id = "Zxda6O8OHP58VUd07OoF"
client_secret = "h65D3z_YOw"
header = {'X-Naver-Client-Id': client_id, 'X-Naver-Client-Secret': client_secret, 'Content-Type':'application/json'}
url = "https://openapi.naver.com/v1/datalab/search"
body = "{\"startDate\":\"2017-01-01\",\"endDate\":\"2020-07-29\",\"timeUnit\":\"month\",\"keywordGroups\":[{\"groupName\":\"검색\",\"keywords\":[\"미숫가루\"]}]}"

response = requests.post(url, headers = header, data = body.encode('utf-8'))
search = json.loads(response.content)
data4graph = search['results'][0]['data']
df4graph = pd.DataFrame(data4graph)


# bokeh
from math import pi
df4graph['period'] = pd.to_datetime(df4graph['period'])

output_file('./plot.html', mode='inline')

p = figure(title='TEST', x_axis_type="datetime", x_axis_label='period', y_axis_label='trend ratio', plot_height=500, plot_width=1500)

from bokeh.models.formatters import DatetimeTickFormatter
p.xaxis.formatter = DatetimeTickFormatter(months=["%Y/%m/%d"])
p.xaxis.major_label_orientation = pi/3

p.line(df4graph.period, df4graph.ratio, legend_label='trend ratio', line_width=2, color='cadetblue', alpha=0.9)
show(p)

# jsonified_p = json_item(model=p, target="myplot")
# return render_template('sub.html')
