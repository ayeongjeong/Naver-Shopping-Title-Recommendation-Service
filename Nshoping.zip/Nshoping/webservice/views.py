from django.http import HttpResponse
from django.shortcuts import render

def main(request):
    return render(request, template_name='main.html')
    
def sub(request):
    data = request.GET.copy()
    return render(request,template_name='sub.html', context=data)