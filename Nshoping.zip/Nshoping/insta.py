from background_task import background
import time
import datetime as dt
import sqlite3
import requests
from bs4 import BeautifulSoup
from selenium import webdriver
import urllib.request
import schedule

# headless options (브라우저 뜨지 않음)
options = webdriver.ChromeOptions()
options.add_argument('headless')
options.add_argument('window-size=1920x1080')
options.add_argument("disable-gpu")

# URL
driver = webdriver.Chrome('/home/sundooedu/문서/instagram/chromedriver', chrome_options=options)
loginUrl = 'https://www.instagram.com/explore/tags/'+ '미숫가루'
driver.implicitly_wait(5)
driver.get(loginUrl)


# 크롤링
def crawling_img():
    source = driver.page_source
    soup = BeautifulSoup(source, 'html.parser')
    img_all = soup.find_all('img', class_='FFVAD')

    img_list = []
    for i in range(3):
        img_list.append(img_all[i]['src'])