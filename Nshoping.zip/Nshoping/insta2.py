import requests
from bs4 import BeautifulSoup

res = requests.get('https://www.instagram.com/explore/tags/'+'미숫가루')
soup = BeautifulSoup(res.content, 'html.parser')
# img_all = soup.find_all('img', class_='FFVAD')
img_all = soup.find_all('div', class_='EZdmt')

# img_list = []
# for i in range(3):
#     img_list.append(img_all[i]['src'])

print()